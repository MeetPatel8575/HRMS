import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

import '../../constants.dart';
import 'components/header.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        primary: false,
        padding: const EdgeInsets.all(defaultPadding),
        child: Column(
          children: [
            const Header(),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  decoration: const BoxDecoration(
                      color: secondaryColor,
                      // border: Border.all(color: Colors.black, width: 1.0),
                      borderRadius: BorderRadius.all(Radius.circular(10))),
                  // width: 500,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 0, vertical: 16),
                  margin:
                      const EdgeInsets.symmetric(horizontal: 0, vertical: 5),
                  child: const Row(
                    // mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: <Widget>[
                      SizedBox(width: 50),
                      Text(
                        'Dashboard',
                        style: TextStyle(
                          decoration: TextDecoration.underline,
                        ),
                      ),
                      SizedBox(width: 130),
                      Text('Group chat'),
                      SizedBox(width: 130),
                      Text('Approvals'),
                      SizedBox(width: 130),
                      Text('Benefits'),
                      SizedBox(width: 130),
                    ],
                  ),
                ),
                const SizedBox(
                  width: 20,
                ),
                Container(
                    decoration: const BoxDecoration(
                        color: secondaryColor,
                        borderRadius: BorderRadius.all(Radius.circular(10))),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 16),
                    margin:
                        const EdgeInsets.symmetric(horizontal: 0, vertical: 5),
                    child: const Row(
                      children: [
                        Icon(Icons.play_circle_fill),
                        SizedBox(
                          width: 10,
                        ),
                        Text('checkin 04:01:45'),
                      ],
                    )),
                const SizedBox(
                  width: 30,
                ),
              ],
            ),
            const SizedBox(height: defaultPadding),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  flex: 5,
                  child: Column(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(16.0),
                        decoration: BoxDecoration(
                            color: secondaryColor,
                            borderRadius: BorderRadius.circular(10)),
                        height: 150,
                        child: const Row(
                          children: [
                            SizedBox(
                              width: 20,
                            ),
                            Icon(
                              Icons.insert_drive_file,
                              size: 50.0,
                              color: Colors.blue,
                            ),
                            SizedBox(width: 18.0),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Project Plan',
                                    style: TextStyle(fontSize: 21.0),
                                  ),
                                  Text(
                                    'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys',
                                    style: TextStyle(
                                        fontSize: 14.0, color: Colors.grey),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: defaultPadding),
                      Row(
                        children: [
                          Column(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(defaultPadding),
                                decoration: BoxDecoration(
                                    color: secondaryColor,
                                    borderRadius: BorderRadius.circular(10)),
                                child: Column(
                                  children: [
                                    Row(
                                      children: [
                                        const Icon(
                                            Icons.insert_drive_file_outlined),
                                        const SizedBox(width: 10),
                                        Row(
                                          children: [
                                            const Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  'Project Plan',
                                                  style:
                                                      TextStyle(fontSize: 21.0),
                                                ),
                                                Text(
                                                  'It department ',
                                                  style: TextStyle(
                                                      fontSize: 14.0,
                                                      color: Colors.grey),
                                                ),
                                              ],
                                            ),
                                            DropdownButton<String>(
                                              value: 'Networking',
                                              onChanged: (String? newValue) {},
                                              items: <String>[
                                                'Networking',
                                                'Option 2',
                                                'Option 3',
                                                'Option 4'
                                              ].map((String value) {
                                                return DropdownMenuItem<String>(
                                                  value: value,
                                                  child: Text(value),
                                                );
                                              }).toList(),
                                            ),
                                          ],
                                        )
                                      ],
                                    ),
                                    const SizedBox(height: 20),
                                    Container(
                                      decoration: BoxDecoration(
                                          color: secondaryColor,
                                          borderRadius:
                                              BorderRadius.circular(10)),
                                      width: 300,
                                      height: 300,
                                      child: AspectRatio(
                                        aspectRatio: 1.0,
                                        child: PieChart(
                                          PieChartData(
                                            sectionsSpace: 2,
                                            centerSpaceRadius: 50,
                                            sections: getSections(),
                                            borderData:
                                                FlBorderData(show: false),
                                          ),
                                        ),
                                      ),
                                    ),
                                    const LegendItem(
                                        color: Colors.green, label: 'Present'),
                                    const LegendItem(
                                        color: Colors.red, label: 'On Duty'),
                                    const LegendItem(
                                        color: Colors.blue, label: 'Absent'),
                                    const LegendItem(
                                        color: Colors.amberAccent,
                                        label: 'Unpaid Leave'),
                                    const LegendItem(
                                        color: Colors.blueGrey,
                                        label: 'Weekend'),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(
                            width: 20,
                          ),
                          Container(
                            padding: const EdgeInsets.all(30),
                            decoration: BoxDecoration(
                                color: secondaryColor,
                                borderRadius: BorderRadius.circular(10)),
                            child: Row(
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      decoration: BoxDecoration(
                                          color: secondaryColor,
                                          borderRadius:
                                              BorderRadius.circular(10)),
                                      width: 80,
                                      child: Column(
                                        children: [
                                          const SizedBox(
                                            height: 55,
                                          ),
                                          Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                decoration: BoxDecoration(
                                                    color: secondaryColor,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            10)),
                                                child: Table(
                                                  border: TableBorder.all(
                                                    color: Colors.transparent,
                                                  ),
                                                  defaultColumnWidth:
                                                      const IntrinsicColumnWidth(),
                                                  children: const [
                                                    TableRow(
                                                      children: [
                                                        SizedBox(
                                                          height: 55,
                                                        ),
                                                        TableCell(
                                                          child:
                                                              Text('01:00 PM'),
                                                        ),
                                                      ],
                                                    ),
                                                    TableRow(
                                                      children: [
                                                        SizedBox(
                                                          height: 55,
                                                        ),
                                                        TableCell(
                                                          child:
                                                              Text('12:00 PM'),
                                                        ),
                                                      ],
                                                    ),
                                                    TableRow(
                                                      children: [
                                                        SizedBox(
                                                          height: 55,
                                                        ),
                                                        TableCell(
                                                          child:
                                                              Text('11:00 AM'),
                                                        ),
                                                      ],
                                                    ),
                                                    TableRow(
                                                      children: [
                                                        SizedBox(
                                                          height: 55,
                                                        ),
                                                        TableCell(
                                                          child:
                                                              Text('10:00 AM'),
                                                        ),
                                                      ],
                                                    ),
                                                    TableRow(
                                                      children: [
                                                        SizedBox(
                                                          height: 55,
                                                        ),
                                                        TableCell(
                                                          child:
                                                              Text('09:00 AM'),
                                                        ),
                                                      ],
                                                    ),
                                                    TableRow(
                                                      children: [
                                                        SizedBox(
                                                          height: 55,
                                                        ),
                                                        TableCell(
                                                          child:
                                                              Text('08:00 AM'),
                                                        ),
                                                      ],
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                                Column(
                                  children: [
                                    Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Table(
                                          border: TableBorder.all(
                                            color: Colors.transparent,
                                          ),
                                          defaultColumnWidth:
                                              const IntrinsicColumnWidth(),
                                          children: const [
                                            TableRow(
                                              children: [
                                                TableCell(
                                                  child: SizedBox(
                                                    width: 50,
                                                    child: Center(
                                                      child: Column(
                                                        children: [
                                                          Text('24'),
                                                          Text('Sun'),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                TableCell(
                                                  child: SizedBox(
                                                    width: 50,
                                                    child: Center(
                                                      child: Column(
                                                        children: [
                                                          Text('25'),
                                                          Text('Mon'),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                TableCell(
                                                  child: SizedBox(
                                                    width: 50,
                                                    child: Center(
                                                      child: Column(
                                                        children: [
                                                          Text('26'),
                                                          Text('Tue'),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                TableCell(
                                                  child: SizedBox(
                                                    width: 50,
                                                    child: Center(
                                                      child: Column(
                                                        children: [
                                                          Text('27'),
                                                          Text('Wed'),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                TableCell(
                                                  child: SizedBox(
                                                    width: 50,
                                                    child: Center(
                                                      child: Column(
                                                        children: [
                                                          Text('28'),
                                                          Text('Thu'),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                TableCell(
                                                  child: SizedBox(
                                                    width: 50,
                                                    child: Center(
                                                      child: Column(
                                                        children: [
                                                          Text('29'),
                                                          Text('Fri'),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ],
                                        )
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 400,
                                    )
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }

  List<PieChartSectionData> getSections() {
    return List.generate(5, (i) {
      Color color;
      switch (i) {
        case 0:
          color = Colors.green;
          break;
        case 1:
          color = Colors.red;
          break;
        case 2:
          color = Colors.blue;
          break;
        case 3:
          color = Colors.amberAccent;
          break;
        case 4:
          color = Colors.blueGrey;
          break;
        default:
          color = Colors.green;
      }

      return PieChartSectionData(
        color: color,
        value: getSectionValue(i),
        title: '',
        radius: 50,
      );
    });
  }

  double getSectionValue(int index) {
    switch (index) {
      case 0:
        return 345;
      case 1:
        return 23;
      case 2:
        return 54;
      case 3:
        return 77;
      case 4:
        return 22;
      default:
        return 0;
    }
  }
}

class LegendItem extends StatelessWidget {
  final Color color;
  final String label;

  const LegendItem({required this.color, required this.label, super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(8.0),
      child: Row(
        children: [
          Container(
            width: 20,
            height: 20,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color,
            ),
          ),
          const SizedBox(width: 8),
          Text(label),
        ],
      ),
    );
  }
}
